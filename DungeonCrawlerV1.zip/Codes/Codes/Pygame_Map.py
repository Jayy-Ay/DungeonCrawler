import pygame
import random as rn
import os
os.chdir(os.path.dirname(os.path.abspath(__file__)))    # Make sure the Images are loaded

# Initialize
pygame.init()
pygame.display.set_caption('Ai DungeonCrawler Test V.1')  # Title
running = True
game = True
screenWidth = 750
screenHeight = 720
grid = [[None] * (screenWidth // 50) for _ in range(400 // 50)]
playerPosition = [[None] * (screenWidth // 50) for _ in range(400 // 50)]
playerTile = 0
combat = False

numCols = (len(grid[0]) if grid else 0) - 1
numRows = (len(grid))

playerPosition[numRows - 1][0] = 1
grid[numRows - 1][0] = 1
bossGenerated = False

while game:

    while running:

        screen = pygame.display.set_mode((720, 750))  # Screen size

        font = pygame.font.SysFont("Consolas", 25)  # Text (font,size)
        clock = pygame.time.Clock()  # Clock
        dt = 1  # Delta Time

        letterGap = 20
        currentOption = 1
        maxOptions = 0
        mapUpdates = 1
        prevOption = 0
        moveMenuActive = False
        menuArray = []


        # if in menu, call this function
        # desc: this function draws the menu, and allows the user to iterate through using arrow keys and enter/space bar
        # this function also returns a result of the menu selection
        def menuSelection(x):
            draw_text("Move", font, (255, 255, 255), 40, 460)
            draw_text("Fight", font, (255, 255, 255), 40, 480)
            draw_text("Items", font, (255, 255, 255), 40, 500)

            pass


        def moveMenu(x):
            draw_text("Up    - W", font, (255, 255, 255), 40, 460)
            draw_text("Left  - A", font, (255, 255, 255), 40, 480)
            draw_text("Down  - S", font, (255, 255, 255), 40, 500)
            draw_text("Right - D", font, (255, 255, 255), 40, 520)
            draw_text("Back  - ESC", font, (255, 255, 255), 40, 540)

            pass


        # if in attack menu, call this function
        # desc: this function draws the attack menu and allows the user to iterate through using arrow keys and enter/space bar
        # this function also returns a result of the menu selection
        def attackMenu(x):
            draw_text("Attack", font, (255, 255, 255), 40, 460)
            draw_text("Back", font, (255, 255, 255), 40, 480)

            pass


        # if in item menu, call this function
        # desc: this function draws the item menu and allows the user to iterate through using arrow keys and enter/space bar
        # this function also returns a result of the menu selection
        def itemMenu(x):
            draw_text("Equip Weapon", font, (255, 255, 255), 40, 460)
            draw_text("Equip Armor", font, (255, 255, 255), 40, 480)
            draw_text("Back", font, (255, 255, 255), 40, 500)

            pass


        def menuHandler(x):
            if x == "Fight":
                return 2
            elif x == "Back":
                return prevOption
            elif x == "Items":
                return 3
            elif x == "Run":
                return 1
            elif x == "Move":
                return 4
            elif x == "Attack":
                for i, row in enumerate(playerPosition):
                    for j, x in enumerate(row):
                        if x is not None:
                            if grid[i][j] == 2 or grid[i][j] == 4:
                                grid[i][j] = 0
                                return 5
                            else:
                                return 2
            else:
                return prevOption


        # Function to draw text
        def draw_text(text, font, text_col, x, y):
            new_asset = font.render(text, True, text_col)
            screen.blit(new_asset, (x, y))


        mapActive = True
        menuSelect = 1
        menuSelected = False
        grSp = 50

        undiscoveredCheck = False

        roomTypes = ["Normal Room", "Undiscovered Room", "Enemy Room", "Empty", "Boss"]
        roomColors = [(255, 255, 255), (60, 60, 60), (100, 0, 0), (30, 30, 30), (150, 0, 170)]

        mapDim = [0, 0, screenWidth, 440]
        pygame.draw.rect(screen, (30, 30, 30), mapDim)

        while mapActive:

            # display (image, (x,y))

            events = pygame.event.get()

            undiscoveredCheck = False
            enemyTileCheck = False
            bossTileCheck = False
            for i, row in enumerate(grid):
                for j, x in enumerate(row):
                    if x is not None:
                        if x == 1:
                            undiscoveredCheck = True
                        if x == 2:
                            enemyTileCheck = True
                        if x == 4:
                            bossTileCheck = True

            if not undiscoveredCheck and not bossGenerated and not enemyTileCheck:
                count = -1
                for i, row in enumerate(grid):
                    for j, x in enumerate(row):
                        if x == 3:
                            count += 1

                randBoss = rn.randint(0, count)
                subCount = 0
                for i, row in enumerate(grid):
                    for j, x in enumerate(row):
                        if x == 3:
                            subCount += 1
                            if subCount == count:
                                grid[i][j] = 4
                                bossGenerated = True
                                bossTileCheck = True
                                mapUpdates += 1

            if bossGenerated and not undiscoveredCheck and not enemyTileCheck and not bossTileCheck:
                grid = [[None] * (screenWidth // 50) for _ in range(400 // 50)]
                playerPosition = [[None] * (screenWidth // 50) for _ in range(400 // 50)]
                playerPosition[numRows - 1][0] = 1
                grid[numRows - 1][0] = 1
                bossGenerated = False

            # map drawing
            while mapUpdates > 0:
                pygame.draw.rect(screen, (30, 30, 30), mapDim)
                for i, row in enumerate(grid):
                    for j, x in enumerate(row):
                        if x is not None:
                            pygame.draw.rect(screen, roomColors[x], ((grSp * j + 5), (grSp * i + 40), 45, 45))

                for i, row in enumerate(playerPosition):
                    for j, x in enumerate(row):
                        if x is not None:
                            pygame.draw.circle(screen, (0, 100, 0), (grSp * j + 27.5, grSp * i + 62.5), 5)
                            counter = 1
                            if grid[i][j] == 1:
                                randType = rn.randint(0, 3)
                                if randType == 3:
                                    randType = 2
                                    playerTile = 2
                                else:
                                    randType = 0
                                grid[i][j] = randType
                                mapUpdates += 1
                                if grid[i][j] == 4:
                                    playerTile = 4

                                # map generating
                                neighbors = []
                                if i - 1 >= 0:
                                    if grid[i - 1][j] is None:
                                        neighbors.append("Up")  # Upper neighbor
                                if i + 1 < numRows:
                                    if grid[i + 1][j] is None:
                                        neighbors.append("Down")  # Lower neighbor
                                if j - 1 >= 0:
                                    if grid[i][j - 1] is None:
                                        neighbors.append("Left")  # Left neighbor
                                if j + 1 < numCols:
                                    if grid[i][j + 1] is None:
                                        neighbors.append("Right")  # Right neighbor

                                threshold = 85

                                rn.shuffle(neighbors)
                                for n in neighbors:
                                    randGen = rn.randint(0, 100)
                                    if randGen >= threshold or counter == 1:
                                        match n:
                                            case "Up":
                                                grid[i - 1][j] = 1
                                                mapUpdates += 1
                                                counter -= 1

                                            case "Down":
                                                grid[i + 1][j] = 1
                                                mapUpdates += 1
                                                counter -= 1

                                            case "Left":
                                                grid[i][j - 1] = 1
                                                mapUpdates += 1
                                                counter -= 1

                                            case "Right":
                                                grid[i][j + 1] = 1
                                                mapUpdates += 1
                                                counter -= 1

                                    else:
                                        threshold -= (25 / len(neighbors) - 1)
                                        match n:
                                            case "Up":
                                                grid[i - 1][j] = 3
                                                mapUpdates += 1

                                            case "Down":
                                                grid[i + 1][j] = 3
                                                mapUpdates += 1

                                            case "Left":
                                                grid[i][j - 1] = 3
                                                mapUpdates += 1

                                            case "Right":
                                                grid[i][j + 1] = 3
                                                mapUpdates += 1
                                        neighbors.remove(n)

                                        grid[numRows - 1][0] = 0

                mapUpdates -= 1

            # menu determining
            while not menuSelected:
                pygame.draw.rect(screen, (0, 0, 0), (0, 460, screenWidth, screenHeight))
                draw_text("•", font, (255, 255, 255), 20, 460)

                match menuSelect:
                    case 1:
                        menuSelection(events)
                        maxOptions = 3
                        menuSelected = True
                        currentOption = 1
                        prevOption = 1
                        menuArray = ["Move", "Fight", "Items"]

                    case 2:
                        attackMenu(events)
                        maxOptions = 2
                        menuSelected = True
                        currentOption = 1
                        menuArray = ["Attack", "Back"]

                    case 3:
                        itemMenu(events)
                        maxOptions = 3
                        menuSelected = True
                        currentOption = 1
                        menuArray = ["Weapon", "Armour", "Back"]

                    case 4:
                        pygame.draw.rect(screen, (0, 0, 0), (0, 460, screenWidth, screenHeight))
                        moveMenu(events)
                        menuSelected = True
                        moveMenuActive = True

                    case 5:
                        combat = True
                        mapActive = False
                        running = False
                        break

            # Player Input#
            for event in events:
                if event.type == pygame.KEYDOWN:
                    if moveMenuActive:
                        moved = False
                        for i, row in enumerate(playerPosition):
                            for j, x in enumerate(row):
                                if event.key == pygame.K_UP or event.key == pygame.K_w:
                                    if x is not None:
                                        if i - 1 >= 0:
                                            if grid[i - 1][j] is not None and grid[i - 1][j] != 3:
                                                if not moved:
                                                    playerPosition[i][j] = None
                                                    playerPosition[i - 1][j] = 1
                                                    mapUpdates += 1
                                                    playerTile = grid[i - 1][j]

                                if event.key == pygame.K_DOWN or event.key == pygame.K_s:
                                    if x is not None:
                                        if i + 1 < numRows:
                                            if grid[i + 1][j] is not None and grid[i + 1][j] != 3:
                                                if not moved:
                                                    playerPosition[i][j] = None
                                                    playerPosition[i + 1][j] = 1
                                                    mapUpdates += 1
                                                    moved = True
                                                    playerTile = grid[i+1][j]

                                if event.key == pygame.K_LEFT or event.key == pygame.K_a:
                                    if x is not None:
                                        if j - 1 >= 0:
                                            if grid[i][j - 1] is not None and grid[i][j - 1] != 3:
                                                if not moved:
                                                    playerPosition[i][j] = None
                                                    playerPosition[i][j - 1] = 1
                                                    mapUpdates += 1
                                                    playerTile = grid[i][j-1]

                                if event.key == pygame.K_RIGHT or event.key == pygame.K_d:
                                    if x is not None:
                                        if j + 1 < numCols:
                                            if grid[i][j + 1] is not None and grid[i][j + 1] != 3:
                                                if not moved:
                                                    playerPosition[i][j] = None
                                                    playerPosition[i][j + 1] = 1
                                                    mapUpdates += 1
                                                    moved = True
                                                    playerTile = grid[i][j+1]

                        if event.key == pygame.K_BACKSPACE or event.key == pygame.K_ESCAPE:
                            moveMenuActive = False
                            menuSelect = menuHandler(prevOption)
                            pygame.draw.rect(screen, (0, 0, 0), (0, 460, screenWidth, screenHeight))
                            menuSelection(events)
                            draw_text("•", font, (255, 255, 255), 20, 460)
                            mapUpdates += 1

                    else:
                        if event.key == pygame.K_DOWN:
                            endY = 500
                            if maxOptions > currentOption > 0:
                                pygame.draw.rect(screen, (0, 0, 0), (0, 460, 40, 500))
                                currentOption = currentOption + 1
                                draw_text("•", font, (255, 255, 255), 20, 440 + (letterGap * currentOption))
                                pygame.display.update()

                        if event.key == pygame.K_UP:
                            if maxOptions >= currentOption > 1:
                                pygame.draw.rect(screen, (0, 0, 0), (0, 460, 40, 500))
                                currentOption = currentOption - 1
                                draw_text("•", font, (255, 255, 255), 20, 440 + (letterGap * currentOption))
                                pygame.display.update()

                        if event.key == pygame.K_RETURN:
                            menuSelect = menuHandler(menuArray[currentOption - 1])
                            menuSelected = False
                            mapUpdates += 1

            pygame.display.update()
            pygame.display.flip()  # flip() the display to put your work on screen
            dt = clock.tick(60) / 1000  # limits FPS to 60
            # Press X button on top right corner of window to close program
            for event in events:
                if event.type == pygame.QUIT:
                    combat = False
                    running = False
                    mapActive = False
                    game = False

    while combat:
        # Displaying the Screen
        combat_panel = 150  # The panel to show hp, text, etc.
        combat_screenWidth = 600
        combat_screenHeight = 400 + combat_panel
        combat_screen = pygame.display.set_mode((combat_screenWidth, combat_screenHeight))
        pygame.display.set_caption('Combat Mode')

        # Define colors, fonts, and images
        red = (255, 0, 0)
        green = (0, 255, 0)
        font = pygame.font.SysFont("Arial", 26)
        background_img = pygame.image.load("./imgs/back.jpg").convert_alpha()
        panel_img = pygame.image.load("./imgs/panel.jpg").convert_alpha()


        # Draws Text
        def draw_text(text, font, text_col, x, y):
            img = font.render(text, True, text_col)
            combat_screen.blit(img, (x, y))


        # Draws background
        def draw_bg():
            combat_screen.blit(background_img, (0, 0))


        # Draw info/action panel [UPDATE PYTHON TO NEWEST VER. IF NOT WORKING]
        def draw_panel():
            combat_screen.blit(panel_img, (0, 370))

            # Draw Hero HP
            if hero.hp >= hero.max_hp * (0.5):
                draw_text(f"{hero.name} HP: {hero.hp}", font, green, 100, combat_screenHeight - combat_panel + 10)
            else:
                draw_text(f"{hero.name} HP: {hero.hp}", font, red, 100, combat_screenHeight - combat_panel + 10)

            # Draw Enemies HP
            for count, enemy in enumerate(enemy_list):
                if enemy.hp >= hero.max_hp * (0.5):
                    draw_text(f"{enemy.name} HP: {enemy.hp}", font, green, 330,
                              combat_screenHeight - combat_panel + 10 + count * 40)
                else:
                    draw_text(f"{enemy.name} HP: {enemy.hp}", font, red, 330,
                              combat_screenHeight - combat_panel + 10 + count * 40)


        # Characters
        class entity():
            def __init__(self, x, y, name, max_hp, dmg):
                self.name = name
                self.x = x
                self.y = y
                self.name = name
                self.max_hp = max_hp
                self.hp = max_hp
                self.dmg = dmg
                self.alive = True
                self.weapon = 0  # Weapon's Damage
                self.armour = 0  # Armour's Mitigation

                # Displaying Image
                self.img = pygame.image.load(
                    f"./imgs/{self.name}.png").convert_alpha()

            def resize(self, amount, ):
                self.img = pygame.transform.scale(self.img, (
                    self.img.get_width() * amount, self.img.get_height() * amount))  # Resize image [custom]
                self.rect = self.img.get_rect()  # Get's Width and Height of Image
                self.rect.center = (self.x, self.y)

            def attack(self, target):
                # Attack
                dmg = self.dmg + rn.randint(-8, 4) + self.weapon - target.armour
                if dmg < 0:
                    dmg = 0
                    print("ATTACK MISSED")
                target.hp -= dmg

                # Check if dead
                if target.hp < 1:
                    target.alive = False

            def draw(self):
                combat_screen.blit(self.img, self.rect)


        hero = entity(140, 240, "Hero", 100, 10)
        hero.resize(1 / 4)
        enemy1 = entity(300, 240, "Enemy", 20, 3)
        enemy1.resize(1 / 4)
        enemy2 = entity(350, 240, "Enemy", 20, 3)
        enemy2.resize(1 / 4)
        enemy3 = entity(400, 240, "Enemy", 20, 3)
        enemy3.resize(1 / 4)
        boss = entity(300, 150, "Boss", 100, 10)
        boss.resize(2)

        # Defining Turn-Based Variables
        turn = 1  # Start as 1
        turn_total = None
        wait = 0  # wait before doing action. To make sure things dont move too fast
        wait_total = 70

        combat = True
        enemy_list = []

        if playerTile == 4:
            enemy_list.append(boss)
        elif playerTile == 2:
            enemyNumber = rn.randint(1, 3)
            print(enemyNumber)
            match enemyNumber:
                case 1:
                    enemy_list.append(enemy1)
                case 2:
                    enemy_list.append(enemy1)
                    enemy_list.append(enemy2)
                case 3:
                    enemy_list.append(enemy1)
                    enemy_list.append(enemy2)
                    enemy_list.append(enemy3)

        while combat:

            turn_total = len(enemy_list) + 1  # Total turns is all enemies + player

            # Player's Turn
            if hero.alive and turn == 1:  # If player is alive and his turn
                wait += 1
                if wait >= wait_total:
                    # Attack The First Alive Enemy
                    for enemy in enemy_list:
                        if enemy.alive:
                            hero.attack(enemy)
                            break
                    turn += 1
                    wait = 0

            # Enemy's Turn
            for count, enemy in enumerate(enemy_list):
                if turn == 2 + count:
                    if enemy.alive:
                        wait += 1
                        if wait >= wait_total:
                            # Attack Player
                            enemy.attack(hero)
                            turn += 1
                            wait = 0
                    else:
                        turn += 1  # If enemy is dead, move to next enemy turn

            if turn > turn_total:  # If everyone has turn, reset
                turn = 1

            # Drawing
            draw_bg()
            draw_panel()
            existingEnemy = False
            for enemy in enemy_list:  # Instead of manual typing all enemies, put in list and draw
                if enemy.alive:
                    enemy.draw()
                    existingEnemy = True
            if not existingEnemy:
                combat = False
                running = True

            if hero.hp == 0:
                combat = False
                running = False
                mapActive = False
                game = False
                pygame.quit()

            hero.draw()

            pygame.display.update()
            pygame.display.flip()  # flip() the display to put your work on screen
            dt = clock.tick(60) / 1000  # limits FPS to 60
            # Press X button on top right corner of window to close program
            for event in events:
                if event.type == pygame.QUIT:
                    combat = False
                    running = False
                    mapActive = False
                    game = False

        # Press X button on top right corner of window to close program
        for event in events:
            if event.type == pygame.QUIT:
                combat = False
                running = False
                mapActive = False
                game = False

pygame.quit()
